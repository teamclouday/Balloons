var searchData=
[
  ['log_5fbase_2ehpp',['log_base.hpp',['../a00050.html',1,'']]]
];
